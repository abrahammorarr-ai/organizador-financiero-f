// =======================
// SUPABASE CONFIG
// =======================
const SUPABASE_URL = "https://pjxycfrlerqqslzvjazh.supabase.co";
const SUPABASE_KEY = "sb_publishable_RQ5epA_QzpQGgJqGQG3lbA_zMzb-0bJ";

const supabase = window.supabase.createClient(
  SUPABASE_URL,
  SUPABASE_KEY
);

// =======================
// PANTALLAS
// =======================
const loginScreen = document.getElementById("login-screen");
const appScreen = document.getElementById("app");
const usernameSpan = document.getElementById("username");

// =======================
// SESIÓN
// =======================
async function checkSession() {
  const { data } = await supabase.auth.getSession();

  if (data.session) {
    iniciarApp(data.session.user);
  }
}

checkSession();

// =======================
// INICIO APP
// =======================
function iniciarApp(user) {
  loginScreen.style.display = "none";
  appScreen.style.display = "block";

  usernameSpan.textContent = user.email;
  document.getElementById("perfil-usuario").textContent = user.email;

  cargarMovimientos();
}

// =======================
// LOGIN
// =======================
async function login() {
  const email = document.getElementById("login-user").value.trim();
  const password = document.getElementById("login-pass").value.trim();

  if (!email || !password) {
    alert("Completa los campos");
    return;
  }

  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  });

  if (error) {
    alert(error.message);
    return;
  }

  iniciarApp(data.user);
}

// =======================
// REGISTER
// =======================
async function register() {
  const email = document.getElementById("login-user").value.trim();
  const password = document.getElementById("login-pass").value.trim();

  if (!email || !password) {
    alert("Completa los campos");
    return;
  }

  const { error } = await supabase.auth.signUp({
    email,
    password
  });

  if (error) {
    alert(error.message);
    return;
  }

  alert("✅ Usuario creado, ahora inicia sesión");
}

// =======================
// LOGOUT
// =======================
async function logout() {
  await supabase.auth.signOut();
  location.reload();
}

// =======================
// PERFIL
// =======================
function abrirPerfil() {
  document.getElementById("profile-modal").style.display = "flex";
}

function cerrarPerfil() {
  document.getElementById("profile-modal").style.display = "none";
}

// =======================
// MOVIMIENTOS (SUPABASE)
// =======================
const form = document.getElementById("form-movimiento");
const lista = document.getElementById("lista-movimientos");

const totalIngresos = document.getElementById("total-ingresos");
const totalGastos = document.getElementById("total-gastos");
const totalDeudas = document.getElementById("total-deudas");
const balanceTotal = document.getElementById("balance-total");

const monthButtons = document.querySelectorAll(".month");

let mesActual = "Ene";
let editId = null;
let movimientos = [];

async function cargarMovimientos() {
  const { data, error } = await supabase
    .from("movimientos")
    .select("*")
    .eq("mes", mesActual)
    .order("fecha", { ascending: false });

  if (error) {
    alert("Error cargando movimientos");
    return;
  }

  movimientos = data;
  renderTabla();
  calcularTotales();
}

// =======================
// FORM
// =======================
form.addEventListener("submit", async e => {
  e.preventDefault();

  const data = new FormData(form);
  const mov = Object.fromEntries(data.entries());
  mov.mes = mesActual;
  mov.monto = Number(mov.monto);

  if (editId) {
    await supabase.from("movimientos").update(mov).eq("id", editId);
  } else {
    await supabase.from("movimientos").insert([mov]);
  }

  editId = null;
  form.reset();
  cargarMovimientos();
});

// =======================
// TABLA
// =======================
function renderTabla() {
  lista.innerHTML = "";

  movimientos.forEach(m => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${new Date(m.fecha).toLocaleDateString()}</td>
      <td>${m.descripcion}</td>
      <td>${m.tipo}</td>
      <td>$${m.monto}</td>
      <td>
        <button onclick="editar(${m.id})">✏️</button>
        <button onclick="eliminar(${m.id})">🗑️</button>
      </td>
    `;
    lista.appendChild(tr);
  });
}

window.editar = id => {
  const m = movimientos.find(x => x.id === id);
  form.descripcion.value = m.descripcion;
  form.monto.value = m.monto;
  form.tipo.value = m.tipo;
  form.fecha.value = m.fecha;
  editId = id;
};

window.eliminar = async id => {
  if (!confirm("¿Eliminar movimiento?")) return;

  await supabase.from("movimientos").delete().eq("id", id);
  cargarMovimientos();
};

// =======================
// TOTALES
// =======================
function calcularTotales() {
  let ingresos = 0, gastos = 0, deudas = 0;

  movimientos.forEach(m => {
    if (m.tipo === "ingreso") ingresos += m.monto;
    if (m.tipo === "gasto") gastos += m.monto;
    if (m.tipo === "deuda") deudas += m.monto;
  });

  totalIngresos.textContent = ingresos;
  totalGastos.textContent = gastos;
  totalDeudas.textContent = deudas;
  balanceTotal.textContent = ingresos - gastos - deudas;
}

// =======================
// MESES
// =======================
monthButtons.forEach(btn => {
  btn.addEventListener("click", () => {
    monthButtons.forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    mesActual = btn.dataset.month;
    cargarMovimientos();
  });
});
