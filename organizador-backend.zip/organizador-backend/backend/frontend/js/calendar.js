document.addEventListener("DOMContentLoaded", async function () {
  const calendarEl = document.getElementById("calendar");

  const API_URL = "https://TU-BACKEND.onrender.com";
  const token = localStorage.getItem("token");

  if (!token) {
    alert("Debes iniciar sesión");
    window.location.href = "index.html";
    return;
  }

  const year = new Date().getFullYear();
  const meses = [
    "Ene","Feb","Mar","Abr","May","Jun",
    "Jul","Ago","Sep","Oct","Nov","Dic"
  ];

  let events = [];

  // 🔁 Cargar movimientos de TODOS los meses
  for (const mes of meses) {
    const res = await fetch(`${API_URL}/movimientos/${mes}`, {
      headers: {
        Authorization: token
      }
    });

    const data = await res.json();

    data.movimientos.forEach(m => {
      events.push({
        title:
          (m.tipo === "ingreso" ? "💰 " : m.tipo === "gasto" ? "💸 " : "📉 ") +
          "$" + m.monto,
        start: m.fecha,
        color:
          m.tipo === "ingreso"
            ? "#2ecc71"
            : m.tipo === "gasto"
            ? "#e74c3c"
            : "#f39c12"
      });
    });
  }

  const calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: "dayGridMonth",
    locale: "es",
    height: "auto",
    events
  });

  calendar.render();
});
