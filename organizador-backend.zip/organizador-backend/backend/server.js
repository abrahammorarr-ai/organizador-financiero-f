import express from "express";
import sqlite3 from "sqlite3";
import cors from "cors";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const app = express();
const PORT = process.env.PORT || 3000;
const SECRET = "CLAVE_SECRETA_CAMBIALA";

app.use(cors());
app.use(express.json());

// =====================
// DB
// =====================
const db = new sqlite3.Database("./database.db");

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE,
      password TEXT
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS movimientos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      descripcion TEXT,
      monto REAL,
      tipo TEXT,
      fecha TEXT,
      mes TEXT
    )
  `);
});

// =====================
// AUTH MIDDLEWARE
// =====================
function auth(req, res, next) {
  const token = req.headers.authorization;
  if (!token) return res.status(401).json({ error: "No token" });

  try {
    const decoded = jwt.verify(token, SECRET);
    req.userId = decoded.id;
    next();
  } catch {
    res.status(401).json({ error: "Token inválido" });
  }
}

// =====================
// REGISTER
// =====================
app.post("/register", (req, res) => {
  const { username, password } = req.body;
  const hash = bcrypt.hashSync(password, 10);

  db.run(
    "INSERT INTO users (username, password) VALUES (?, ?)",
    [username, hash],
    err => {
      if (err) return res.status(400).json({ error: "Usuario ya existe" });
      res.json({ ok: true });
    }
  );
});

// =====================
// LOGIN
// =====================
app.post("/login", (req, res) => {
  const { username, password } = req.body;

  db.get(
    "SELECT * FROM users WHERE username = ?",
    [username],
    (err, user) => {
      if (!user) return res.status(401).json({ error: "Credenciales incorrectas" });

      const ok = bcrypt.compareSync(password, user.password);
      if (!ok) return res.status(401).json({ error: "Credenciales incorrectas" });

      const token = jwt.sign({ id: user.id }, SECRET);
      res.json({ token });
    }
  );
});
// =====================
// PERFIL
// =====================
app.get("/me", auth, (req, res) => {
  db.get(
    "SELECT id, username FROM users WHERE id = ?",
    [req.userId],
    (err, user) => {
      if (!user) return res.status(404).json({ error: "Usuario no encontrado" });
      res.json(user);
    }
  );
});

// =====================
// MOVIMIENTOS (PROTEGIDOS)
// =====================
app.get("/movimientos/:mes", auth, (req, res) => {
  db.all(
    "SELECT * FROM movimientos WHERE mes=? AND user_id=?",
    [req.params.mes, req.userId],
    (err, rows) => {
      let ingresos = 0, gastos = 0, deudas = 0;

      rows.forEach(m => {
        if (m.tipo === "ingreso") ingresos += m.monto;
        if (m.tipo === "gasto") gastos += m.monto;
        if (m.tipo === "deuda") deudas += m.monto;
      });

      res.json({
        movimientos: rows,
        totales: {
          ingresos,
          gastos,
          deudas,
          balance: ingresos - gastos - deudas
        }
      });
    }
  );
});

app.post("/movimientos", auth, (req, res) => {
  const { descripcion, monto, tipo, fecha, mes } = req.body;

  db.run(
    `INSERT INTO movimientos (user_id, descripcion, monto, tipo, fecha, mes)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [req.userId, descripcion, monto, tipo, fecha, mes],
    () => res.json({ ok: true })
  );
});

app.put("/movimientos/:id", auth, (req, res) => {
  const { descripcion, monto, tipo, fecha } = req.body;

  db.run(
    `UPDATE movimientos SET descripcion=?, monto=?, tipo=?, fecha=?
     WHERE id=? AND user_id=?`,
    [descripcion, monto, tipo, fecha, req.params.id, req.userId],
    () => res.json({ ok: true })
  );
});

app.delete("/movimientos/:id", auth, (req, res) => {
  db.run(
    "DELETE FROM movimientos WHERE id=? AND user_id=?",
    [req.params.id, req.userId],
    () => res.json({ ok: true })
  );
});

app.listen(PORT, "0.0.0.0", () => {
  console.log("🔥 Backend listo");
});
// =====================
// CAMBIAR CONTRASEÑA
// =====================
app.post("/change-password", auth, (req, res) => {
  const { actual, nueva } = req.body;

  if (!actual || !nueva) {
    return res.status(400).json({ error: "Faltan datos" });
  }

  db.get(
    "SELECT * FROM users WHERE id = ?",
    [req.userId],
    (err, user) => {
      if (!user) return res.status(404).json({ error: "Usuario no encontrado" });

      const ok = bcrypt.compareSync(actual, user.password);
      if (!ok) {
        return res.status(401).json({ error: "Contraseña actual incorrecta" });
      }

      const hash = bcrypt.hashSync(nueva, 10);

      db.run(
        "UPDATE users SET password = ? WHERE id = ?",
        [hash, req.userId],
        () => res.json({ ok: true })
      );
    }
  );
});
// =====================
// PERFIL USUARIO
// =====================
app.get("/me", auth, (req, res) => {
  db.get(
    "SELECT id, username FROM users WHERE id = ?",
    [req.userId],
    (err, user) => {
      if (!user) return res.status(404).json({ error: "Usuario no encontrado" });
      res.json(user);
    }
  );
});
